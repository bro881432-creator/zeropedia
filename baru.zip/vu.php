<?php
// vu.php - HALAMAN MENUL LIST PEMAIN
$configFile = 'config.json';
if (file_exists($configFile)) {
    $daftar_game = json_decode(file_get_contents($configFile), true);
} else {
    echo "Data game belum diseting oleh Admin di SIM.php";
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Joker Gaming List</title>
    <style>
        body { background-color: #121212; color: #ffffff; font-family: Arial, sans-serif; padding: 20px; text-align: center; }
        h1 { color: #f39c12; }
        .container { display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; margin-top: 30px; }
        .game-card { background-color: #1e1e1e; border: 2px solid #333; border-radius: 8px; width: 220px; padding: 15px; box-shadow: 0 4px 8px rgba(0,0,0,0.5); position: relative; }
        .game-title { font-size: 15px; font-weight: bold; margin: 10px 0; height: 35px; }
        .winrate-tag { font-size: 11px; background: #d35400; padding: 3px 8px; border-radius: 10px; display: inline-block; margin-bottom: 10px; }
        .btn-play { display: block; background-color: #f39c12; color: #fff; padding: 8px; text-decoration: none; border-radius: 4px; font-weight: bold; }
        .btn-mt { display: block; background-color: #c0392b; color: #fff; padding: 8px; text-decoration: none; border-radius: 4px; font-weight: bold; pointer-events: none; }
    </style>
</head>
<body>

    <h1>🎰 JOKER GAMING SLOT SELECTION 🎰</h1>
    
    <div class="container">
        <?php foreach ($daftar_game as $id => $game): ?>
            <div class="game-card">
                <div style="width:100%; height:110px; background-color:#2c3e50; border-radius:4px; line-height:110px; color:#aaa;">IMAGE</div>
                <div class="game-title"><?php echo $game['name']; ?></div>
                
                <!-- Menampilkan Win Rate yang Anda set di SIM.php -->
                <div class="winrate-tag">RTP: <?php echo $game['win_rate']; ?>%</div>
                
                <?php if ($game['status'] == 'Aktif'): ?>
                    <a href="https://t.me/UsernameBotAnda?start=play_<?php echo $id; ?>" target="_blank" class="btn-play">MAIN SEKARANG</a>
                <?php else: ?>
                    <a href="#" class="btn-mt">MAINTENANCE</a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

</body>
</html>
