<?php
// SIM.php - HALAMAN DASHBOARD ADMIN
$configFile = 'config.json';

// Daftar 23 Game Master Data
$master_game = [
    ["id" => "JG-rmpyyz4hmijfg", "name" => "Zombie Zircus"], ["id" => "JG-ibee7wqs49kpk", "name" => "Blockade Runner"],
    ["id" => "JG-ek7gyx3h8w3dg", "name" => "Fortune Clover 40"], ["id" => "JG-zid3zqi5znh5h", "name" => "Winning Horse"],
    ["id" => "JG-q48fayayyrdyq", "name" => "Heavenly Beasts"], ["id" => "JG-ipkauigi3mfho", "name" => "Book Of Thermopylae"],
    ["id" => "JG-6ogpfdcnoqyen", "name" => "Christmas Fortune"], ["id" => "JG-r8poqz19mtqir", "name" => "Super Fortune Crown"],
    ["id" => "JG-d5uyes4amfxf6", "name" => "Maya Ways"], ["id" => "JG-x4dkj69a989x6", "name" => "Super Seven Seas"],
    ["id" => "JG-aha65cfts455e", "name" => "Fire Master Hold And Win"], ["id" => "JG-c1qrr8e1ncebn", "name" => "Fortune Crown Gold Gift"],
    ["id" => "JG-3r369pizs144w", "name" => "Mahjong King"], ["id" => "JG-uiu5zss55dc7h", "name" => "Chilli Hunter Bandidos"],
    ["id" => "JG-gxgtnunpejbwy", "name" => "Steamboat Ride"], ["id" => "JG-mno8hejgrh1nk", "name" => "Seven Seas"],
    ["id" => "JG-m4uregaadrxb6", "name" => "Fortune Crown 25"], ["id" => "JG-es9sgctugyauc", "name" => "Savage Frontier"],
    ["id" => "JG-1bwmp4xq79sq4", "name" => "Black Knight"], ["id" => "JG-xgbi6bo8yon9w", "name" => "Carnaval Do Rio"],
    ["id" => "JG-gz8tgo1debywc", "name" => "Chocolate Shop"], ["id" => "JG-si838osdadyhc", "name" => "Fire Temple"],
    ["id" => "JG-ym7ny95hxi38g", "name" => "Fortune Crown"]
];

// Load data saat ini atau buat baru jika belum ada
if (file_exists($configFile)) {
    $current_data = json_decode(file_get_contents($configFile), true);
} else {
    $current_data = [];
    foreach ($master_game as $mg) {
        $current_data[$mg['id']] = ['name' => $mg['name'], 'status' => 'Aktif', 'win_rate' => 50];
    }
    file_put_contents($configFile, json_encode($current_data));
}

// Proses jika admin menekan tombol Simpan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($current_data as $id => $data) {
        if (isset($_POST['status'][$id])) {
            $current_data[$id]['status'] = $_POST['status'][$id];
            $current_data[$id]['win_rate'] = intval($_POST['win_rate'][$id]);
        }
    }
    file_put_contents($configFile, json_encode($current_data));
    $pesan = "Pengaturan berhasil diperbarui!";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>CONTROL PANEL - SIM</title>
    <style>
        body { font-family: sans-serif; background: #222; color: #fff; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 10px; border: 1px solid #444; text-align: left; }
        th { background: #333; color: #f39c12; }
        select, input { padding: 5px; background: #444; color: #fff; border: 1px solid #666; }
        .btn { background: #f39c12; color: #fff; border: 0; padding: 10px 20px; font-weight: bold; cursor: pointer; border-radius: 4px; }
        .alert { background: #27ae60; padding: 10px; margin-bottom: 15px; border-radius: 4px; }
    </style>
</head>
<body>
    <h2>⚙️ PANEL KONTROL GAME (SIM.php)</h2>
    <?php if (isset($pesan)) echo "<div class='alert'>$pesan</div>"; ?>
    
    <form method="POST">
        <table>
            <tr>
                <th>ID Game</th>
                <th>Nama Game</th>
                <th>Status Menu</th>
                <th>Setting Win Rate (%)</th>
            </tr>
            <?php foreach ($current_data as $id => $game): ?>
            <tr>
                <td><?php echo $id; ?></td>
                <td><?php echo $game['name']; ?></td>
                <td>
                    <select name="status[<?php echo $id; ?>]">
                        <option value="Aktif" <?php if($game['status']=='Aktif') echo 'selected'; ?>>Aktif / ON</option>
                        <option value="MT" <?php if($game['status']=='MT') echo 'selected'; ?>>Maintenance / OFF</option>
                    </select>
                </td>
                <td>
                    <input type="number" name="win_rate[<?php echo $id; ?>]" value="<?php echo $game['win_rate']; ?>" min="0" max="100">%
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <br>
        <button type="submit" class="btn">SIMPAN PERUBAHAN</button>
    </form>
</body>
</html>
