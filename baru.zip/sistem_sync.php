<?php
session_start();
header('Content-Type: application/json');
$db_file = 'database.json';

if (!file_exists($db_file)) {
    file_put_contents($db_file, json_encode([], JSON_PRETTY_PRINT));
}
$db = json_decode(file_get_contents($db_file), true) ?: [];

$action = isset($_GET['action']) ? $_GET['action'] : '';

// 1. SIMULASI HARGA LIVE & CHART
if ($action === 'get_price') {
    srand(floor(time() / 10)); // Harga berubah setiap 10 detik
    $base_price = 25000;
    $change = (rand(0, 2000) - 1000);
    $current_price = $base_price + $change;
    
    // Generate data chart acak untuk estetika trading
    $chart_data = [];
    for ($i = 0; $i < 15; $i++) {
        $chart_data[] = $base_price + (sin($i) * 500) + (rand(0, 600) - 300);
    }
    $chart_data[] = $current_price;

    // Simulasi Antrean Bid / Ask Market Depth
    $bids = []; $asks = [];
    for($i=1; $i<=4; $i++) {
        $bids[] = ['harga' => $current_price - ($i * 50), 'vol' => rand(10, 150)];
        $asks[] = ['harga' => $current_price + ($i * 50), 'vol' => rand(10, 150)];
    }

    echo json_encode([
        'status' => 'success',
        'harga' => $current_price,
        'chart_data' => $chart_data,
        'bids' => $bids,
        'asks' => $asks
    ]);
    exit;
}

// 2. PROSES DAFTAR TIKET DEPOSIT DARI USER
if ($action === 'user_deposit') {
    if (!isset($_SESSION['user_login'])) { echo json_encode(['status' => 'error', 'msg' => 'Sesi habis']); exit; }
    $user = $_SESSION['user_login'];
    $nominal = (int)$_POST['nominal'];

    if ($nominal < 10000) {
        echo json_encode(['status' => 'error', 'msg' => 'Minimal deposit Rp 10.000']);
        exit;
    }

    $ticket = [
        'id_tiket' => 'DEP-' . rand(100000, 999999),
        'nominal' => $nominal,
        'status' => 'pending',
        'waktu' => date('Y-m-d H:i:s')
    ];

    $db[$user]['deposit'][] = $ticket;
    $db[$user]['logs'][] = ["waktu" => date('H:i:s'), "teks" => "Mengajukan deposit: Rp " . number_format($nominal)];
    
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    echo json_encode(['status' => 'success', 'msg' => 'Tiket deposit berhasil dibuat', 'data' => $ticket]);
    exit;
}

// 3. PROSES DAFTAR TIKET WITHDRAW DARI USER
if ($action === 'user_withdraw') {
    if (!isset($_SESSION['user_login'])) { echo json_encode(['status' => 'error', 'msg' => 'Sesi habis']); exit; }
    $user = $_SESSION['user_login'];
    $nominal = (int)$_POST['nominal'];

    if ($nominal <= 0 || $db[$user]['saldo'] < $nominal) {
        echo json_encode(['status' => 'error', 'msg' => 'Saldo akun tidak mencukupi']);
        exit;
    }

    $ticket = [
        'id_tiket' => 'WD-' . rand(100000, 999999),
        'nominal' => $nominal,
        'status' => 'pending',
        'waktu' => date('Y-m-d H:i:s')
    ];

    $db[$user]['withdraw'][] = $ticket;
    $db[$user]['logs'][] = ["waktu" => date('H:i:s'), "teks" => "Mengajukan penarikan: Rp " . number_format($nominal)];
    
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    echo json_encode(['status' => 'success', 'msg' => 'Tiket penarikan berhasil diajukan']);
    exit;
}

// 4. TRADING INSTRUMEN (BELI / JUAL LOT)
if ($action === 'trade') {
    if (!isset($_SESSION['user_login'])) { echo json_encode(['status' => 'error', 'msg' => 'Sesi habis']); exit; }
    $user = $_SESSION['user_login'];
    $type = $_GET['type'];
    $qty = (int)$_GET['qty'];
    $price = (int)$_GET['price'];

    if ($qty <= 0) { echo json_encode(['status' => 'error', 'msg' => 'Jumlah lot tidak valid']); exit; }
    $total_cost = $qty * $price;

    if ($type === 'buy') {
        if ($db[$user]['saldo'] < $total_cost) { echo json_encode(['status' => 'error', 'msg' => 'Saldo tidak cukup']); exit; }
        $db[$user]['saldo'] -= $total_cost;
        $db[$user]['saham_dimiliki'] += $qty;
        $db[$user]['logs'][] = ["waktu" => date('H:i:s'), "teks" => "Beli $qty Lot aset pada harga Rp " . number_format($price)];
    } else {
        if ($db[$user]['saham_dimiliki'] < $qty) { echo json_encode(['status' => 'error', 'msg' => 'Lot tidak cukup']); exit; }
        $db[$user]['saham_dimiliki'] -= $qty;
        $db[$user]['saldo'] += $total_cost;
        $db[$user]['logs'][] = ["waktu" => date('H:i:s'), "teks" => "Jual $qty Lot aset pada harga Rp " . number_format($price)];
    }

    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    echo json_encode(['status' => 'success', 'msg' => 'Transaksi berhasil dieksekusi']);
    exit;
}

echo json_encode(['status' => 'error', 'msg' => 'Aksi tidak dikenali']);
?>
