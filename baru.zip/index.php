<?php
session_start();
$db_file = 'database.json';
$db = json_decode(file_get_contents($db_file), true) ?: [];

// PROSES DAFTAR AKUN
if (isset($_POST['register'])) {
    $username = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['username']);
    if (isset($db[$username])) {
        echo "<script>alert('ID Akun sudah dialokasikan / digunakan');</script>";
    } else {
        $db[$username] = [
            'username' => $username, 'password' => $_POST['password'],
            'bank' => $_POST['bank'], 'norek' => $_POST['norek'], 'nama_rek' => $_POST['nama_rek'],
            'saldo' => 0, 'saham_dimiliki' => 0, 'deposit' => [], 'withdraw' => [],
            'logs' => [["waktu" => date('H:i:s'), "teks" => "Akun baru terdaftar resmi"]]
        ];
        file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
        $_SESSION['user_login'] = $username;
        header("Location: index.php"); exit;
    }
}

// PROSES LOGIN
if (isset($_POST['login'])) {
    $username = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['username']);
    if (isset($db[$username]) && $db[$username]['password'] === $_POST['password']) {
        $_SESSION['user_login'] = $username;
        header("Location: index.php"); exit;
    } else {
        echo "<script>alert('Kredensial Akses Salah');</script>";
    }
}

if (isset($_GET['logout'])) { session_destroy(); header("Location: index.php"); exit; }

$u = [];
if (isset($_SESSION['user_login']) && isset($db[$_SESSION['user_login']])) {
    $u = $db[$_SESSION['user_login']];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZERO PEDIA - Client Terminal</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --bg-dark: #05070f; --panel-color: #0b0f1e; --border-color: #161f36;
            --accent-gold: #e67e22; --text-light: #f1f2f6; --text-gray: #5c6b82;
            --green: #00c853; --red: #ff3d00;
        }
        * { box-sizing: border-box; font-family: sans-serif; }
        body { background: #010205; color: var(--text-light); margin: 0; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 450px; min-height: 100vh; background: var(--bg-dark); border-left: 1px solid var(--border-color); border-right: 1px solid var(--border-color); padding-bottom: 80px; position: relative; }
        
        .terminal-header { padding: 15px 20px; background: var(--panel-color); border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; }
        .content { padding: 12px; }
        .card-pro { background: var(--panel-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 15px; margin-bottom: 12px; }
        
        .auth-input { width: 100%; background: #020306; border: 1px solid var(--border-color); padding: 12px; border-radius: 6px; color: #fff; margin-bottom: 10px; }
        .btn-pro { width: 100%; padding: 12px; background: var(--accent-gold); border: none; color: #fff; font-weight: 700; border-radius: 6px; cursor: pointer; }
        
        .action-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 15px; }
        .btn-gate { padding: 12px; border: 1px solid var(--border-color); color: #fff; text-align: center; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: bold; }
        
        .order-book-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 11px; margin-top: 8px; }
        .ob-row { display: flex; justify-content: space-between; padding: 3px 0; font-family: monospace; }
        
        .bottom-navbar { position: fixed; bottom: 0; width: 100%; max-width: 450px; background: var(--panel-color); border-top: 1px solid var(--border-color); display: flex; justify-content: space-around; padding: 12px 0; }
        .nav-link { color: var(--text-gray); text-decoration: none; font-size: 10px; display: flex; flex-direction: column; align-items: center; gap: 4px; }
        .nav-link.active { color: var(--accent-gold); }
        .hidden { display: none !important; }
    </style>
</head>
<body>

<div class="app-container">
    <div class="terminal-header">
        <div>
            <h1 style="margin:0; font-size:16px;">ZERO PEDIA</h1>
            <span style="font-size:8px; color:var(--text-gray);">LIQUIDITY APP PORT v4.0</span>
        </div>
        <div style="font-size:9px; color:var(--green); font-weight:bold;">SECURE CONNECTION</div>
    </div>

    <div class="content">
        <?php if (!isset($_SESSION['user_login'])): ?>
            <div class="card-pro">
                <h3 id="auth-title" style="text-align:center; margin-top:0;">Otorisasi Klien</h3>
                <form method="POST" id="form-login">
                    <input type="text" name="username" class="auth-input" placeholder="ID Pengguna" required>
                    <input type="password" name="password" class="auth-input" placeholder="Kata Sandi" required>
                    <button type="submit" name="login" class="btn-pro">MASUK TERMINAL</button>
                    <p style="text-align:center; font-size:11px; color:var(--text-gray); cursor:pointer; margin-top:15px;" onclick="toggleAuth('reg')">Pendaftaran Akun Baru</p>
                </form>

                <form method="POST" id="form-reg" class="hidden">
                    <input type="text" name="username" class="auth-input" placeholder="Buat ID Pengguna Baru" required>
                    <input type="password" name="password" class="auth-input" placeholder="Buat Kata Sandi" required>
                    <select name="bank" class="auth-input" required>
                        <option value="">Metode Settlement Penarikan</option>
                        <option value="BANK BCA">BANK BCA</option>
                        <option value="DANA">E-WALLET DANA</option>
                        <option value="GOPAY">E-WALLET GOPAY</option>
                    </select>
                    <input type="number" name="norek" class="auth-input" placeholder="Nomor Rekening / Dana" required>
                    <input type="text" name="nama_rek" class="auth-input" placeholder="Nama Pemilik Akun" required>
                    <button type="submit" name="register" class="btn-pro">DAFTARKAN MITRA</button>
                    <p style="text-align:center; font-size:11px; color:var(--text-gray); cursor:pointer; margin-top:15px;" onclick="toggleAuth('login')">Kembali ke Log In</p>
                </form>
            </div>
            <script>
                function toggleAuth(v) {
                    if(v==='reg') { document.getElementById('form-login').classList.add('hidden'); document.getElementById('form-reg').classList.remove('hidden'); }
                    else { document.getElementById('form-reg').classList.add('hidden'); document.getElementById('form-login').classList.remove('hidden'); }
                }
            </script>

        <?php else: $page = isset($_GET['page']) ? $_GET['page'] : 'dashboard'; ?>
            
            <div id="p-dashboard" class="<?php echo $page=='dashboard'?'':'hidden'; ?>">
                <div class="card-pro">
                    <div style="font-size:10px; color:var(--text-gray); text-transform:uppercase;">Total Net Asset Value (NAV)</div>
                    <div style="font-size:28px; font-weight:bold; margin:5px 0;" id="dash-nav">Rp 0</div>
                    <div style="font-size:11px; color:var(--text-gray);">
                        Dana Likuid: <span style="color:var(--green)">Rp <?php echo number_format($u['saldo']); ?></span> | 
                        Portofolio: <span style="color:var(--accent-gold)"><?php echo $u['saham_dimiliki']; ?> Lot</span>
                    </div>
                    <div class="action-grid">
                        <a href="index.php?page=topup" class="btn-gate" style="border-color:var(--green); color:var(--green)">DEPOSIT</a>
                        <a href="index.php?page=wd" class="btn-gate" style="border-color:var(--red); color:var(--red)">WITHDRAW</a>
                    </div>
                </div>

                <div class="card-pro">
                    <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                        <span style="font-size:11px; color:var(--text-gray);">REALTIME INDEX</span>
                        <strong id="live-price" style="color:#fff;">IDR 0</strong>
                    </div>
                    <canvas id="userChart" height="120"></canvas>
                </div>
                
                <div style="text-align:center;"><a href="index.php?logout=1" style="font-size:12px; color:var(--red); text-decoration:none;">Keluar Sesi Aman</a></div>
            </div>

            <div id="p-terminal" class="<?php echo $page=='terminal'?'':'hidden'; ?>">
                <div class="card-pro">
                    <div style="font-size:11px; color:var(--text-gray); font-weight:bold; text-transform:uppercase;">Order Book Market Depth</div>
                    <div class="order-book-grid">
                        <div><div style="color:var(--green); font-weight:bold; margin-bottom:4px;">Bid</div><div id="bids-area"></div></div>
                        <div><div style="color:var(--red); font-weight:bold; margin-bottom:4px;">Ask</div><div id="asks-area"></div></div>
                    </div>
                </div>
                <div class="card-pro">
                    <div style="font-size:11px; color:var(--text-gray); font-weight:bold; text-transform:uppercase; margin-bottom:10px;">Eksekusi Instan</div>
                    <input type="number" id="trade-qty" class="auth-input" value="1" min="1" style="text-align:center; font-size:16px;">
                    <div class="action-grid">
                        <button class="btn-pro" style="background:var(--green);" onclick="executeTrade('buy')">BELI LOT</button>
                        <button class="btn-pro" style="background:var(--red);" onclick="executeTrade('sell')">JUAL LOT</button>
                    </div>
                </div>
            </div>

            <div id="p-topup" class="<?php echo $page=='topup'?'':'hidden'; ?>">
                <div class="card-pro">
                    <h4 style="margin-top:0; font-size:14px; letter-spacing:0.5px;">ALOKASI DEPOSIT BARU</h4>
                    <p style="font-size:11px; color:var(--text-gray); line-height:1.4; margin-bottom:12px;">
                        Masukkan nominal dana. Sistem akan membuat tiket antrean otomatis ke terminal admin.
                    </p>
                    
                    <input type="number" id="input-depo" class="auth-input" placeholder="Nominal Saldo (Min. 10.000)" style="font-weight:bold;">
                    <button class="btn-pro" onclick="submitDepositTicket()">PROSES TIKET DEPOSIT</button>

                    <div id="invoice-specs" class="hidden" style="background: #020306; border: 1px dashed var(--border-color); padding: 15px; border-radius: 6px; text-align: center; margin-top: 15px;">
                        <div id="inv-num" style="font-size:11px; font-weight:bold; color:var(--text-gray); font-family:monospace;"></div>
                        <hr style="border:0; border-top:1px solid var(--border-color); margin:10px 0;">
                        
                        <div style="font-size:11px; color:var(--text-gray);">JUMLAH YANG HARUS DITRANSFER</div>
                        <div id="inv-total" style="font-size: 22px; font-weight: bold; color: var(--accent-gold); margin: 8px 0; font-family: monospace;">Rp 0</div>
                        
                        <img src="qris_admin.png" alt="QRIS PAYMENT" style="width:160px; height:160px; margin:10px auto; display:block; border-radius:4px; border: 2px solid #fff;">
                        
                        <div style="background:#05070f; padding:10px; border-radius:4px; font-size:11px; text-align:left; line-height:1.5; border:1px solid var(--border-color); margin-bottom:12px;">
                            <span style="color:var(--text-gray);">Metode Alternatif:</span><br>
                            Bank Koresponden: <strong>BANK CENTRAL ASIA (BCA)</strong><br>
                            Nomor Rekening: <strong>8140XXXXXX</strong><br>
                            Atas Nama: <strong>ZERO TEAM RECORDING</strong>
                        </div>
                        
                        <button class="btn-pro" style="background:transparent; border:1px solid var(--green); color:var(--green); font-size:12px; padding:8px;" onclick="confirmPaymentDone()">
                            SAYA SUDAH SELESAI TRANSFER
                        </button>
                    </div>
                </div>
            </div>

            <div id="p-wd" class="<?php echo $page=='wd'?'':'hidden'; ?>">
                <div class="card-pro">
                    <h4 style="margin-top:0;">Pengajuan Pencairan</h4>
                    <input type="number" id="input-wd" class="auth-input" placeholder="Masukkan Nominal Penarikan">
                    <button class="btn-pro" style="background:var(--red);" onclick="submitWdTicket()">AJUKAN WITHDRAWAL</button>
                </div>
            </div>

            <div class="bottom-navbar">
                <a href="index.php?page=dashboard" class="nav-link <?php echo $page=='dashboard'?'active':''; ?>">Dashboard</a>
                <a href="index.php?page=terminal" class="nav-link <?php echo $page=='terminal'?'active':''; ?>">Pasar</a>
                <a href="index.php?page=topup" class="nav-link <?php echo $page=='topup'?'active':''; ?>">Deposit</a>
                <a href="index.php?page=wd" class="nav-link <?php echo $page=='wd'?'active':''; ?>">Withdraw</a>
            </div>

            <script>
                let activePrice = 0;
                let userSaldo = <?php echo $u['saldo']; ?>;
                let userSaham = <?php echo $u['saham_dimiliki']; ?>;

                const ctx = document.getElementById('userChart').getContext('2d');
                const myChart = new Chart(ctx, {
                    type: 'line', data: { labels: Array(16).fill(''), datasets: [{ data: [], borderColor: '#e67e22', tension: 0.2, pointRadius: 0, fill: false }] },
                    options: { responsive: true, animation: false, plugins: { legend: { display: false } }, scales: { x: { display: false }, y: { ticks: { color: '#5c6b82' } } } }
                });

                function loopSyncEngine() {
                    fetch('sistem_sync.php?action=get_price')
                    .then(r => r.json())
                    .then(res => {
                        if (res.status === 'success') {
                            activePrice = res.harga;
                            document.getElementById('live-price').innerText = 'IDR ' + activePrice.toLocaleString('id-ID');
                            
                            let navCalculated = userSaldo + (userSaham * activePrice);
                            document.getElementById('dash-nav').innerText = 'Rp ' + navCalculated.toLocaleString('id-ID');

                            myChart.data.datasets[0].data = res.chart_data;
                            myChart.update();

                            let bHtml = ''; res.bids.forEach(b => { bHtml += `<div class="ob-row"><span>${b.harga}</span><span style="color:var(--green)">${b.vol}</span></div>` });
                            if (document.getElementById('bids-area')) document.getElementById('bids-area').innerHTML = bHtml;

                            let aHtml = ''; res.asks.forEach(a => { aHtml += `<div class="ob-row"><span>${a.harga}</span><span style="color:var(--red)">${a.vol}</span></div>` });
                            if (document.getElementById('asks-area')) document.getElementById('asks-area').innerHTML = aHtml;
                        }
                    });
                }

                function executeTrade(type) {
                    let qty = document.getElementById('trade-qty').value;
                    fetch(`sistem_sync.php?action=trade&type=${type}&qty=${qty}&price=${activePrice}`)
                    .then(r => r.json()).then(res => { alert(res.msg); window.location.reload(); });
                }

                function submitDepositTicket() {
                    let nom = parseInt(document.getElementById('input-depo').value);
                    if(!nom || nom < 10000) { alert('Batas minimal deposit adalah IDR 10.000'); return; }
                    
                    let uniqueCode = Math.floor(Math.random() * 899) + 100;
                    let totalTransfer = nom + uniqueCode;
                    
                    let fd = new FormData(); 
                    fd.append('nominal', totalTransfer);
                    
                    fetch('sistem_sync.php?action=user_deposit', { method: 'POST', body: fd })
                    .then(r => r.json())
                    .then(res => { 
                        if(res.status === 'success') {
                            document.getElementById('inv-num').innerText = "NOTA INVOICE: #" + res.data.id_tiket;
                            document.getElementById('inv-total').innerText = "Rp " + totalTransfer.toLocaleString('id-ID');
                            document.getElementById('invoice-specs').classList.remove('hidden');
                            alert('Tiket berhasil dibuat! Silakan transfer sesuai nominal unik.');
                        } else {
                            alert(res.msg);
                        }
                    });
                }

                function submitWdTicket() {
                    let nom = document.getElementById('input-wd').value;
                    let fd = new FormData(); fd.append('nominal', nom);
                    fetch('sistem_sync.php?action=user_withdraw', { method: 'POST', body: fd })
                    .then(r => r.json()).then(res => { alert(res.msg); if(res.status==='success') window.location.href='index.php?page=dashboard'; });
                }

                function confirmPaymentDone() {
                    alert('Permintaan verifikasi manual diajukan ke admin. Proses audit dana memerlukan waktu 5-10 menit.');
                    window.location.href = 'index.php?page=dashboard';
                }

                setInterval(loopSyncEngine, 3000);
                loopSyncEngine();
            </script>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
