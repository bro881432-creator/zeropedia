<?php
session_start();
$db_file = 'database.json';
$db = json_decode(file_get_contents($db_file), true) ?: [];

// Konfigurasi File Musik Default
$music_config_file = 'music_config.json';
$music_info = file_exists($music_config_file) ? json_decode(file_get_contents($music_config_file), true) : ['file_path' => ''];

// PROSES UPLOAD MUSIK BARU OLEH ADMIN
if (isset($_POST['upload_music']) && isset($_SESSION['admin_logged'])) {
    if (isset($_FILES['audio_file']) && $_FILES['audio_file']['error'] == 0) {
        $allowed = ['mp3', 'wav', 'ogg'];
        $filename = $_FILES['audio_file']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $target_dir = "uploads/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            
            // Simpan dengan nama tetap agar tidak menumpuk sampah file di server
            $target_file = $target_dir . "bg_music." . $ext;
            if (move_uploaded_file($_FILES['audio_file']['tmp_name'], $target_file)) {
                $music_info['file_path'] = $target_file;
                file_put_contents($music_config_file, json_encode($music_info));
                echo "<script>alert('Musik latar berhasil diperbarui!'); window.location.href='admin.php';</script>"; exit;
            } else {
                echo "<script>alert('Gagal memindahkan file ke server!');</script>";
            }
        } else {
            echo "<script>alert('Format file tidak didukung! Gunakan MP3, WAV, atau OGG.');</script>";
        }
    }
}

// VALIDASI AKSES ADMIN (KEY: 89)
if (isset($_POST['admin_login'])) {
    if (trim($_POST['admin_key']) === '89') {
        $_SESSION['admin_logged'] = true;
        header("Location: admin.php"); exit;
    } else {
        echo "<script>alert('Kunci Otorisasi Admin Salah!');</script>";
    }
}

if (isset($_GET['admin_logout'])) {
    unset($_SESSION['admin_logged']);
    header("Location: admin.php"); exit;
}

// Memproses persetujuan (ACC DEPO / WD)
if (isset($_GET['action']) && isset($_SESSION['admin_logged'])) {
    $target = $_GET['user'];
    $index = (int)$_GET['index'];
    
    if ($_GET['action'] === 'acc_depo' && isset($db[$target]['deposit'][$index])) {
        $nominal = $db[$target]['deposit'][$index]['nominal'];
        $db[$target]['saldo'] += $nominal;
        $db[$target]['deposit'][$index]['status'] = 'success';
        $db[$target]['logs'][] = ["waktu" => date('H:i:s'), "teks" => "Deposit Rp " . number_format($nominal) . " DISETUJUI oleh admin."];
    }
    
    if ($_GET['action'] === 'acc_wd' && isset($db[$target]['withdraw'][$index])) {
        $nominal = $db[$target]['withdraw'][$index]['nominal'];
        if ($db[$target]['saldo'] >= $nominal) {
            $db[$target]['saldo'] -= $nominal;
            $db[$target]['withdraw'][$index]['status'] = 'success';
            $db[$target]['logs'][] = ["waktu" => date('H:i:s'), "teks" => "Penarikan Rp " . number_format($nominal) . " SUKSES dicairkan."];
        }
    }
    
    file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
    header("Location: admin.php"); exit;
}

// Simpan Modifikasi Manual
if (isset($_POST['update_manual']) && isset($_SESSION['admin_logged'])) {
    $target = $_POST['target_user'];
    if (isset($db[$target])) {
        $db[$target]['saldo'] = (int)$_POST['saldo'];
        $db[$target]['saham_dimiliki'] = (int)$_POST['saham'];
        file_put_contents($db_file, json_encode($db, JSON_PRETTY_PRINT));
        header("Location: admin.php"); exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZERO PEDIA - Core Admin Control</title>
    <style>
        :root {
            --bg-dark: #060913; --panel-color: #0d1222; --border-color: #1e2942;
            --accent-gold: #e67e22; --text-light: #f1f2f6; --text-gray: #627595;
            --red: #ff3d00; --green: #00c853;
        }
        * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, sans-serif; }
        body { background: var(--bg-dark); color: var(--text-light); margin: 0; padding: 0; display: flex; justify-content: center; min-height: 100vh; }
        .admin-container { width: 100%; max-width: 500px; background: #03050a; border-left: 1px solid var(--border-color); border-right: 1px solid var(--border-color); padding: 20px; padding-bottom: 80px; }
        
        /* LOGIN BG MOUNT FUJI */
        .login-gateway { 
            position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
            background: linear-gradient(rgba(6, 9, 19, 0.6), rgba(6, 9, 19, 0.85)), 
                        url('https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=1000&auto=format&fit=crop') no-repeat center center; 
            background-size: cover; display: flex; justify-content: center; align-items: center; z-index: 9999;
        }
        .login-card { background: rgba(13, 18, 34, 0.85); border: 1px solid rgba(230, 126, 34, 0.25); border-radius: 12px; padding: 35px; width: 90%; max-width: 360px; backdrop-filter: blur(12px); text-align: center; }
        
        .panel-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); padding-bottom: 15px; margin-bottom: 25px; }
        .card-user { background: var(--panel-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 15px; margin-bottom: 15px; }
        
        .input-style { width: 100%; background: #05070f; border: 1px solid var(--border-color); padding: 12px; border-radius: 6px; color: #fff; margin-bottom: 15px; font-weight: bold; text-align: center; }
        .btn-gold { width: 100%; padding: 12px; background: var(--accent-gold); border: none; color: #fff; font-weight: 700; border-radius: 6px; cursor: pointer; }
        
        .ticket-row { background: #060913; border: 1px solid var(--border-color); padding: 10px; border-radius: 6px; margin: 6px 0; display: flex; justify-content: space-between; align-items: center; font-size: 12px; }
        .btn-acc { padding: 6px 12px; font-size: 11px; font-weight: bold; color: #fff; text-decoration: none; border-radius: 4px; }
        
        .grid-half { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 12px; }
        .grid-half input { width: 100%; background: #05070f; border: 1px solid var(--border-color); padding: 8px; border-radius: 4px; color: #fff; text-align: center; font-family: monospace; }
        
        /* CONTROLLER PEMUTAR MUSIK FLUID */
        .audio-dock { position: fixed; bottom: 15px; right: 15px; background: rgba(13, 18, 34, 0.95); border: 1px solid var(--border-color); padding: 10px 15px; border-radius: 30px; display: flex; align-items: center; gap: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.4); z-index: 10000; }
        .music-btn { background: var(--accent-gold); border: none; color: white; border-radius: 50%; width: 28px; height: 28px; font-weight: bold; cursor: pointer; font-size: 11px; display: flex; align-items: center; justify-content: center; }
    </style>
</head>
<body>

<?php if (!empty($music_info['file_path'])): ?>
    <audio id="bgAudio" src="<?php echo $music_info['file_path']; ?>" loop></audio>
<?php endif; ?>

<div class="audio-dock">
    <span style="font-size: 10px; color: var(--text-gray); font-weight: bold;">MUSIC BGM</span>
    <button class="music-btn" id="musicToggleBtn" onclick="toggleMusicState()">▶</button>
</div>

<?php if (!isset($_SESSION['admin_logged'])): ?>
    <div class="login-gateway">
        <div class="login-card">
            <h2 style="margin: 0 0 5px 0; font-size: 18px; letter-spacing: 1px;">ZERO CONTROL</h2>
            <div style="font-size: 10px; color: var(--accent-gold); font-weight: bold; letter-spacing: 2px; margin-bottom: 25px;">SECURE MONITOR GATE</div>
            <form method="POST" onsubmit="forceStartMusic()">
                <input type="password" name="admin_key" class="input-style" placeholder="MASUKKAN KUNCI AKSES" autocomplete="off" required>
                <button type="submit" name="admin_login" class="btn-gold">VALIDASI OTORITAS</button>
            </form>
        </div>
    </div>
<?php else: ?>
    <div class="admin-container">
        <div class="panel-header">
            <div>
                <h3 style="margin: 0; font-size: 16px;">Otoritas Bursa Pusat</h3>
                <span style="font-size: 10px; color: var(--text-gray);">SINKRONISASI TIKET TRANSAKSI REAL-TIME</span>
            </div>
            <a href="admin.php?admin_logout=1" style="font-size: 11px; color: var(--red); font-weight: bold; text-decoration: none;">PUTUS KONEKSI</a>
        </div>

        <div class="card-user" style="border-color: rgba(230, 126, 34, 0.3);">
            <div style="font-size: 11px; color: var(--accent-gold); font-weight: bold; margin-bottom: 8px; text-transform: uppercase;">Pengaturan Hub Audio Core</div>
            <form method="POST" enctype="multipart/form-data">
                <input type="file" name="audio_file" accept=".mp3,.wav,.ogg" style="font-size: 11px; color: var(--text-gray); margin-bottom: 10px; display: block;" required>
                <button type="submit" name="upload_music" class="btn-gold" style="padding: 6px; font-size: 11px; background: transparent; border: 1px solid var(--accent-gold); color: var(--accent-gold);">
                    UNGGAH & TERAPKAN MUSIK LATAR
                </button>
            </form>
        </div>

        <h4 style="font-size: 11px; color: var(--text-gray); text-transform: uppercase; margin-bottom: 15px; letter-spacing: 0.5px;">Daftar Akun Klien Bursa</h4>
        
        <?php if (empty($db)): ?>
            <p style="text-align: center; font-size: 12px; color: var(--text-gray); margin-top: 40px;">Belum ada pengguna yang mendaftar.</p>
        <?php else: ?>
            <?php foreach ($db as $username => $user): ?>
                <div class="card-user">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 12px;">
                        <div>ID Klien: <strong style="color:#fff; font-size:14px;"><?php echo htmlspecialchars($username); ?></strong></div>
                        <div style="color: var(--text-gray); font-family: monospace;">Pass: <?php echo htmlspecialchars($user['password']); ?></div>
                    </div>

                    <div style="font-size: 11px; background: #060913; padding: 8px; border-radius: 4px; margin-bottom: 12px; border: 1px solid var(--border-color); line-height: 1.4;">
                        Metode: <strong><?php echo htmlspecialchars($user['bank']); ?></strong> — <?php echo htmlspecialchars($user['norek']); ?><br>
                        A.N. <?php echo htmlspecialchars($user['nama_rek']); ?>
                    </div>

                    <div style="font-size: 10px; color: var(--accent-gold); font-weight: bold; margin-top: 10px;">ANTREAN TIKET DEPOSIT</div>
                    <?php 
                    $d_count = 0;
                    if(isset($user['deposit'])):
                        foreach($user['deposit'] as $idx => $d):
                            if($d['status'] === 'pending'): $d_count++;
                    ?>
                        <div class="ticket-row">
                            <div>Nominal: <strong style="color:var(--green)">Rp <?php echo number_format($d['nominal']); ?></strong></div>
                            <a href="admin.php?action=acc_depo&user=<?php echo urlencode($username); ?>&index=<?php echo $idx; ?>" class="btn-acc" style="background:var(--green);" onclick="return confirm('Sahkan deposit ini?')">ACC</a>
                        </div>
                    <?php 
                            endif;
                        endforeach;
                    endif; 
                    if($d_count == 0) echo '<div style="font-size:10px; color:var(--text-gray); margin-bottom:10px;">Tidak ada pengajuan deposit</div>';
                    ?>

                    <div style="font-size: 10px; color: var(--red); font-weight: bold; margin-top: 10px;">ANTREAN TIKET PENARIKAN (WD)</div>
                    <?php 
                    $w_count = 0;
                    if(isset($user['withdraw'])):
                        foreach($user['withdraw'] as $idx => $w):
                            if($w['status'] === 'pending'): $w_count++;
                    ?>
                        <div class="ticket-row">
                            <div>Nominal: <strong style="color:var(--red)">Rp <?php echo number_format($w['nominal']); ?></strong></div>
                            <a href="admin.php?action=acc_wd&user=<?php echo urlencode($username); ?>&index=<?php echo $idx; ?>" class="btn-acc" style="background:var(--red);" onclick="return confirm('Setujui pencairan dana ini?')">ACC WD</a>
                        </div>
                    <?php 
                            endif;
                        endforeach;
                    endif; 
                    if($w_count == 0) echo '<div style="font-size:10px; color:var(--text-gray); margin-bottom:15px;">Tidak ada pengajuan penarikan</div>';
                    ?>

                    <form method="POST" style="border-top: 1px dashed var(--border-color); padding-top: 12px; margin-top: 12px;">
                        <input type="hidden" name="target_user" value="<?php echo htmlspecialchars($username); ?>">
                        <div class="grid-half">
                            <div>
                                <span style="font-size:9px; color:var(--text-gray); display:block; margin-bottom:2px;">SALDO LIQUID</span>
                                <input type="number" name="saldo" value="<?php echo $user['saldo']; ?>">
                            </div>
                            <div>
                                <span style="font-size:9px; color:var(--text-gray); display:block; margin-bottom:2px;">PORTOFOLIO (LOT)</span>
                                <input type="number" name="saham" value="<?php echo $user['saham_dimiliki']; ?>">
                            </div>
                        </div>
                        <button type="submit" name="update_manual" class="btn-gold" style="padding:6px; font-size:11px;">UPDATE PERUBAHAN MANUAL</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
<?php endif; ?>

<script>
    const audio = document.getElementById('bgAudio');
    const toggleBtn = document.getElementById('musicToggleBtn');

    // Cek status penyimpanan audio terakhir di browser
    window.addEventListener('DOMContentLoaded', () => {
        if (audio) {
            const savedState = localStorage.getItem('admin_music_playing');
            if (savedState === 'true') {
                attemptAutoplay();
            }
        }
    });

    function attemptAutoplay() {
        audio.play().then(() => {
            toggleBtn.innerText = "║║";
            toggleBtn.style.background = "#00c853";
        }).catch(err => {
            console.log("Autoplay diblokir browser. Menunggu interaksi pertama admin.");
        });
    }

    // Memaksa musik berputar sesaat setelah admin mengetuk tombol login "VALIDASI OTORITAS"
    function forceStartMusic() {
        if (audio) {
            audio.play();
            localStorage.setItem('admin_music_playing', 'true');
        }
    }

    function toggleMusicState() {
        if (!audio) { alert('Silakan unggah file musik latar terlebih dahulu!'); return; }
        
        if (audio.paused) {
            audio.play();
            toggleBtn.innerText = "║║";
            toggleBtn.style.background = "#00c853";
            localStorage.setItem('admin_music_playing', 'true');
        } else {
            audio.pause();
            toggleBtn.innerText = "▶";
            toggleBtn.style.background = "#e67e22";
            localStorage.setItem('admin_music_playing', 'false');
        }
    }
</script>

</body>
</html>
